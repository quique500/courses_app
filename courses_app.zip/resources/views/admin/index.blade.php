@extends('adminlte::page')

@section('title', '<Q-C>')

@section('content_header')
    <h1>Q-Code;</h1>
@stop

@section('content')
    <p>Bienvenido a la pagina de cursos online Q-Code;</p>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> console.log('Hi!'); </script>
@stop
