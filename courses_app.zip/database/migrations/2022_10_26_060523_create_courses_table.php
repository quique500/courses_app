<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\Course;
use PHPUnit\Framework\Constraint\Count;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('courses', function (Blueprint $table) {
            $table->id();

            $table->string('title');
            $table->string('subtitle');
            $table->text('description');
            $table->enum('status',[Course::BORRADOR, Course::REVISION,Course::PUBLICADO])
                ->default(Course::BORRADOR); /* el estatus del video por revisar (se toman los valores estaticos del modelo de la migracion )*/
            $table->string('slug'); /* para generar urls */

            /* crear las FK */
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('level_id')->nullable(); /* nulable es para haceptar campos vacios  */
            $table->unsignedBigInteger('category_id')->nullable();
            $table->unsignedBigInteger('price_id')->nullable();

            /* referencias de las tablas */
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');     /* (ondelete sirve para borrar los cursos de alguien cuando se borra un instructor) */
            $table->foreign('level_id')->references('id')->on('levels')->onDelete('set null');     /* pro si un determinado nivel se elimina quedara como nivel nilo */
            $table->foreign('category_id')->references('id')->on('categories')->onDelete('set null');
            $table->foreign('price_id')->references('id')->on('prices')->onDelete('set null');


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('courses');
    }
};
